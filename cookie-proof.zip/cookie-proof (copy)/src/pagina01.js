import axios from 'axios';
import styled from 'styled-components';

export default function Pagina01(){

    function setar(event){
        const request = axios.get("http://localhost:5000/setcookie",{
            withCredentials:true
          } );
        request.then(response =>{
            console.log(response)
            alert(response.data)
        });
    };
    function pegar(event){
        const request = axios.get("http://localhost:5000/getcookie" ,{
            withCredentials:true
          } );
        request.then(response =>{
            console.log(response.data)
        });
    };
    function deletar(event){
        const request = axios.get("http://localhost:5000/deletecookie",{
            withCredentials:true
          } );
        request.then(response =>{
            console.log(response)
            alert(response.data)
        });        


    };
    return(
        <Container>
           <h1>Olá mundo!</h1>
           <button onClick={setar}>Setar um Cookie!</button>
           <br />
           <button onClick={pegar}>pegar um Cookie!</button>
           <br />
           <button onClick={deletar}>Deletar um Cookie!</button>
        </Container>
    );
}
const Container = styled.div`
display: flex;
flex-direction: column;
align-items: center;
justify-content: center;
margin-top:100px;
`