import { BrowserRouter, Routes, Route } from "react-router-dom";
import Pagina01 from "./pagina01";

export default function App(){

    return(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Pagina01 />} />
                
            </Routes>

        </BrowserRouter>
    );
}